from copy import deepcopy
from enum import Enum, auto
from typing import List, Optional, Tuple
from dataclasses import dataclass

import numpy as np
import tensornetwork as tn
from zquantum.generative.numerical_optimization.fidelity_qcbm import conjugate


from functools import partial
import jax
from jax import jit
import jax.numpy as jnp


tn.set_default_backend("numpy")

SCALE_FACTOR = 1


class State(Enum):
    TRAINING = auto()
    EVAL = auto()


@dataclass
class TNUnitaryNode:
    participating_qubits: Tuple[int, ...]
    node: tn.Node


class Network:
    def __init__(
        self,
        n_initial_layers: Optional[int],
        target_node: tn.Node,
    ):
        self.n_initial_layers = n_initial_layers
        self.target_node = target_node
        self._target_node_conj = self.target_node.copy(conjugate=True)
        self.model_nodes: List[tn.Node] = []
        self.n_qubits = len(self.target_node.edges)

        self._batch_size = None
        self._averaging_batch_size = 1
        self._SUPPORT_BATCHES = False

        self.state = State.EVAL

    def update_unitary_m(
        self,
        which_idx: int,
        learning_rate: float = 1.0,
    ):
        self.state = State.TRAINING
        self.reset_edges()

        m = which_idx
        participating_qubits = self.model_unitaries[m].participating_qubits
        unitary_m: tn.Node = self.model_unitaries[m].node
        ##
        for repetition in range(self.averaging_batch_size):
            trace_nodes = self._get_empty_trace_edges()
            with tn.NodeCollection(trace_nodes):
                qubits = self.get_init_right_edges()
                final_qubits = self.get_target_left_edges()
                self.connect_sandwiching_unitary(
                    m, qubits, final_qubits, conjugate=True
                )

            ## F tensor
            fidelity_tensor = tn.contractors.auto(
                trace_nodes,
                output_edge_order=[
                    qubits[participating_qubits[0]],
                    qubits[participating_qubits[1]],
                    final_qubits[participating_qubits[0]],
                    final_qubits[participating_qubits[1]],
                ],
            )

            if repetition == 0:
                full_fidelity_tensor = fidelity_tensor
            else:
                full_fidelity_tensor = tn.Node(
                    full_fidelity_tensor.tensor + fidelity_tensor.tensor,
                    name="Fidelity Tensor",
                )

        ## Calculate the optimal unitary_m
        x, d, y, _ = tn.split_node_full_svd(
            full_fidelity_tensor,
            left_edges=[full_fidelity_tensor[0], full_fidelity_tensor[1]],
            right_edges=[full_fidelity_tensor[2], full_fidelity_tensor[3]],
        )
        x.fresh_edges()
        y.fresh_edges()
        um = tn.contract(x[-1] ^ y[0])
        if not np.isclose(learning_rate, 1):
            new_tensor = interpolation_function(
                unitary_m.tensor, um.tensor, learning_rate
            )
            um = tn.Node(new_tensor.reshape(4 * [2]))

        unitary_m.set_tensor(um.tensor)
        self.state = State.EVAL

    def get_fidelity(self):
        raise NotImplementedError

    def _get_fidelity_node(self):
        reset_all_node_edges(self.model_nodes)
        trace_nodes = self._get_empty_trace_edges()
        with tn.NodeCollection(trace_nodes):
            self.connect_network()
            self.connect_outer_edges(conjugate=True)
            self.connect_inner_edges(conjugate=True)

        return tn.contractors.auto(trace_nodes)

    def connect_network(self):
        self._sweep_edges = self.get_init_right_edges()
        self.connect_circuit_until_m(self._sweep_edges, self.model_unitaries)

    def connect_sandwiching_unitary(
        self,
        which_idx: int,
        qubits: List[tn.Edge] = None,
        final_qubits: List[tn.Edge] = None,
        participating_qubits: Optional[Tuple[int, int]] = None,
        conjugate: bool = False,
    ):
        if qubits is None:
            qubits = self.get_init_right_edges()
        if final_qubits is None:
            final_qubits = self.get_target_left_edges()

        if not which_idx == -1:
            participating_qubits = self.model_unitaries[which_idx].participating_qubits
            self.connect_circuit_until_m(
                qubits, self.model_unitaries, M=which_idx, conjugate=conjugate
            )

        self.reverse_connect_circuit_until_m(
            final_qubits, self.model_unitaries, M=which_idx, conjugate=conjugate
        )
        ## connect inner edges
        for nq in range(self.n_qubits):
            if nq not in participating_qubits:
                tn.connect(qubits[nq], final_qubits[nq])

    def connect_outer_edges(self, conjugate: Optional[bool] = False):
        pass

    def connect_inner_edges(self, conjugate: Optional[bool] = False):
        target_edges = self.get_target_left_edges(conjugate=conjugate)
        for ii in range(self.n_qubits):
            tn.connect(self._sweep_edges[ii], target_edges[ii])

    def connect_circuit_until_m(
        self,
        qubits: List[tn.Edge],
        all_unitaries: List[TNUnitaryNode],
        M: int = None,
        conjugate: bool = False,
    ):
        """qubits: the initial qubit edges"""
        if M is None or M > len(all_unitaries) + 1:
            M = len(all_unitaries)
        for m, entry in enumerate(all_unitaries[:M]):
            participating_qubits = entry.participating_qubits
            uni = entry.node.copy(conjugate=conjugate)
            qubits = self._forward_connecting(qubits, uni, participating_qubits)

    def _forward_connecting(
        self,
        qubits: List[tn.Edge],
        unitary: tn.Node,
        participating_qubits: Tuple[int, ...],
    ) -> List[tn.Edge]:
        raise NotImplementedError

    def reverse_connect_circuit_until_m(
        self,
        final_qubits: List[tn.Node],
        all_unitaries: List[TNUnitaryNode],
        M: int = None,
        conjugate: bool = False,
    ):
        """target_state: the target state node"""
        if M is None or M > len(all_unitaries):
            M = len(all_unitaries)

        if M >= 0:
            which_unitaries = all_unitaries[:M:-1]
        elif M == -1:
            which_unitaries = all_unitaries[::-1]
        else:
            raise ValueError(f"M should be a positive integer or -1, instead is {M}")

        for m, entry in enumerate(which_unitaries):
            participating_qubits = entry.participating_qubits
            uni = entry.node.copy(conjugate=conjugate)
            for ii, qbit in enumerate(participating_qubits):
                final_qubits[qbit] ^ uni[ii + len(participating_qubits)]
                final_qubits[qbit] = uni[ii]

    @property
    def model_state(self):
        self.reset_edges()
        trace_nodes = self._get_empty_trace_edges()
        with tn.NodeCollection(trace_nodes):
            self.connect_network()
        node = tn.contractors.auto(
            trace_nodes,
            output_edge_order=[*self._sweep_edges],
        )
        node.name = "Model State"
        return node

    def set_initial_unitaries(self, n_layers: int, theta: float = 0.0):
        self.model_unitaries: List[TNUnitaryNode] = []
        for layer in range(n_layers):
            self.model_unitaries.extend(
                get_unitary_linear_layer(
                    self.n_qubits,
                    theta=theta,
                    name_extension=f"l:{layer+1}",
                )
            )

    def get_init_right_edges(self):
        raise NotImplementedError

    def get_init_left_edges(self):
        raise NotImplementedError

    def get_target_left_edges(self, conjugate: Optional[bool] = False):
        raise NotImplementedError

    def get_target_right_edges(self, conjugate: Optional[bool] = False):
        raise NotImplementedError

    def _get_empty_trace_edges(self):
        raise NotImplementedError

    @property
    def batch_size(self):
        if self._SUPPORT_BATCHES:
            return self._batch_size
        else:
            return None

    @property
    def averaging_batch_size(self):
        if self._SUPPORT_BATCHES:
            return self._averaging_batch_size
        else:
            return 1

    def draw_network(self):
        reset_all_node_edges(self.model_nodes + [self.target_node])
        trace_edges = self._get_empty_trace_edges()
        with tn.NodeCollection(trace_edges):
            self.connect_network()
        return self.draw(trace_edges + [self.target_node])

    def draw(self, nodes: List[tn.Node]):
        return tn.to_graphviz(nodes)

    def reset_edges(self):
        reset_all_node_edges(
            self.model_nodes + [self.target_node, self._target_node_conj]
        )


class StateNetwork(Network):
    def __init__(
        self,
        target_node: tn.Node,
        n_initial_layers: Optional[int] = None,
        initial_nodes: Optional[List[tn.Node]] = None,
        model_unitaries: Optional[List[tn.Node]] = None,
    ):
        super().__init__(n_initial_layers, target_node)

        if initial_nodes is None:
            self.initial_nodes = [
                tn.Node(np.array([1.0, 0.0]), name=f"qubit {ii}")
                for ii in range(self.n_qubits)
            ]
            self.num_init_nodes = len(self.initial_nodes)
            self.model_nodes.extend(self.initial_nodes)
        elif isinstance(initial_nodes, list):
            assert len(initial_nodes) == len(target_node.edges)
            self.initial_nodes = initial_nodes
            self.num_init_nodes = len(self.initial_nodes)
            self.model_nodes.extend(self.initial_nodes)

        elif isinstance(initial_nodes, tn.Node):
            assert len(initial_nodes.edges) == len(target_node.edges)
            self.initial_nodes = initial_nodes
            self.num_init_nodes = 1
            self.model_nodes.append(self.initial_nodes)
        else:
            raise Exception("The value passed for 'initial_nodes' is not correct. ")

        if isinstance(self.initial_nodes, list):
            psi_before_flat = self.initial_nodes[0].copy()
            for ii in range(1, self.n_qubits):
                psi_before_flat = tn.outer_product(
                    psi_before_flat, self.initial_nodes[ii].copy(), name="Init State"
                )
            self.full_init_state = psi_before_flat
        else:
            self.full_init_state = self.initial_nodes

        if model_unitaries is not None:
            self.model_unitaries: List[TNUnitaryNode] = deepcopy(model_unitaries)
        else:
            if n_initial_layers is None:
                raise Exception(
                    "Either 'n_initial_layers' or 'initial_nodes' must be passed."
                )
            self.set_initial_unitaries(self.n_initial_layers)
        self.model_nodes.extend([entry.node for entry in self.model_unitaries])

        self._stached_second_to_last_tensor = None

    def update_sweep(
        self,
        learning_rate: float = 0.6,
        update_range: Optional[Tuple[int, int]] = None,
    ):
        assert (
            self.averaging_batch_size == 1 and self.batch_size is None
        ), "'Update_sweep' only works in the exact case. Please use 'update_unitary_m'."
        self.state = State.TRAINING
        if update_range is None:
            update_range = (0, len(self.model_unitaries) - 1)
        #### initial left state: just qubits in zero
        left_state = self.full_init_state

        #### initial right state: back-contracted until the first unitary
        right_state = self.reverse_network_from_target(fully_reverse=False)

        self.forward_sweep(
            left_state,
            right_state,
            update_range=update_range,
            learning_rate=learning_rate,
        )

        self.state = State.EVAL

    def forward_sweep(
        self,
        left_state: tn.Node,
        right_state: tn.Node,
        update_range: Tuple[int, int],
        learning_rate: float = 0.6,
    ):
        left_state_tensor = left_state.tensor
        right_state_tensor = right_state.tensor

        #### loop over the unitaries
        for m in range(len(self.model_unitaries)):
            unitary_node_m: tn.Node = self.model_unitaries[m].node
            participating_qubits = self.model_unitaries[m].participating_qubits

            if m in range(min(update_range), max(update_range) + 1):
                # calculate fidelity tensor
                full_fidelity_tensor = (
                    calculate_fidelity_tensor_from_left_and_right_state(
                        left_state_tensor, right_state_tensor, participating_qubits
                    )
                )

                # Calculate the optimal unitary_m
                new_unitary_tensor = np.array(
                    calculate_new_unitary_tensor(
                        full_fidelity_tensor,
                        unitary_node_m.tensor,
                        learning_rate,
                    )
                )

                unitary_node_m.set_tensor(new_unitary_tensor)

            ### roll the state over to the next unitary
            if m < len(self.model_unitaries) - 1:
                this_unitary_m_tensor = unitary_node_m.tensor.conj()
                left_state_tensor = np.array(
                    apply_unitary(
                        left_state_tensor,
                        this_unitary_m_tensor,
                        participating_qubits,
                    )
                )

                next_unitary_m = self.model_unitaries[m + 1].node  # .copy()
                participating_qubits = self.model_unitaries[m + 1].participating_qubits

                right_state_tensor = np.array(
                    apply_unitary(
                        right_state_tensor,
                        next_unitary_m.tensor,
                        participating_qubits,
                    )
                )

                self._stached_second_to_last_tensor = left_state_tensor

    @property
    def model_state(self):
        if self._stached_second_to_last_tensor is None:
            left_state_tensor = self.full_init_state.tensor
            which_unitaries = self.model_unitaries
        else:
            left_state_tensor = self._stached_second_to_last_tensor
            which_unitaries = self.model_unitaries[-1:]

        for m in range(len(which_unitaries)):
            unitary_node_m: tn.Node = which_unitaries[m].node
            if np.allclose(
                unitary_node_m.tensor.reshape(4, 4), np.eye(4, 4), atol=1e-10
            ):
                continue
            participating_qubits = which_unitaries[m].participating_qubits
            this_unitary_m_tensor = unitary_node_m.tensor.conj()
            left_state_tensor = apply_unitary(
                left_state_tensor,
                this_unitary_m_tensor,
                participating_qubits,
            )
        left_state_tensor = np.array(left_state_tensor)

        model_state_node = tn.Node(left_state_tensor, name="Model State")
        return model_state_node

    def get_fidelity(self):
        return np.abs(
            contract_left_and_right_state(
                self.model_state.tensor, self.target_node.tensor
            )
        )

    def get_init_right_edges(self):
        if isinstance(self.initial_nodes, list):
            return [node[0] for node in self.initial_nodes]
        elif isinstance(self.initial_nodes, tn.Node):
            return [edge for edge in self.initial_nodes.edges]
        else:
            raise Exception(
                f"Wrong type of 'initial_nodes'. Found {type(self.initial_nodes)}"
            )

    def get_init_left_edges(self):
        return []

    def get_target_left_edges(self, conjugate: Optional[bool] = False):
        return [edge for edge in self.target_node.copy(conjugate=conjugate)]

    def get_target_right_edges(self, conjugate: Optional[bool] = False):
        return []

    def _forward_connecting(
        self,
        qubits: List[tn.Edge],
        unitary: tn.Node,
        participating_qubits: Tuple[int, ...],
    ) -> List[tn.Edge]:
        for ii, qbit in enumerate(participating_qubits):
            qubits[qbit] ^ unitary[ii]
            qubits[qbit] = unitary[ii + len(participating_qubits)]
        return qubits

    def _get_empty_trace_edges(self):
        if isinstance(self.initial_nodes, list):
            return [node for node in self.model_nodes[: self.n_qubits]]
        elif isinstance(self.initial_nodes, tn.Node):
            return [self.model_nodes[0]]
        else:
            raise Exception(
                f"Wrong type of 'initial_nodes'. Found {type(self.initial_nodes)}"
            )

    def reverse_network_from_target(self, fully_reverse: bool = True) -> tn.Node:
        right_state = self.target_node
        right_state_tensor = right_state.tensor
        which_unitaries = (
            self.model_unitaries[::-1] if fully_reverse else self.model_unitaries[:0:-1]
        )
        for entry in which_unitaries:
            participating_qubits = entry.participating_qubits
            unitary_tensor = entry.node.tensor
            if np.allclose(unitary_tensor.reshape(4, 4), np.eye(4, 4), atol=1e-10):
                continue
            unitary_tensor = unitary_tensor.conj()
            right_state_tensor = apply_unitary_reverse(
                right_state_tensor, unitary_tensor, participating_qubits
            )
        right_state = tn.Node(np.array(right_state_tensor))
        return right_state


@partial(jax.jit, static_argnames=["qubit_indices"])
def apply_unitary(statevec, unitary, qubit_indices):
    initial_node = tn.Node(statevec, backend="jax")
    unitary_node = tn.Node(unitary, backend="jax")

    output_edges = [edge for edge in initial_node.edges]

    for kk, q_ind in enumerate(qubit_indices):
        output_edges[q_ind] ^ unitary_node[kk]
        output_edges[q_ind] = unitary_node[kk + len(qubit_indices)]

    final_node = tn.contract_between(
        initial_node, unitary_node, output_edge_order=output_edges
    )
    return final_node.tensor


@partial(jax.jit, static_argnames=["qubit_indices"])
def apply_unitary_reverse(statevec, unitary, qubit_indices):
    initial_node = tn.Node(statevec, backend="jax")
    unitary_node = tn.Node(unitary, backend="jax")

    output_edges = [edge for edge in initial_node.edges]

    for kk, q_ind in enumerate(qubit_indices):
        output_edges[q_ind] ^ unitary_node[kk + len(qubit_indices)]
        output_edges[q_ind] = unitary_node[kk]

    final_node = tn.contract_between(
        initial_node, unitary_node, output_edge_order=output_edges
    )
    return final_node.tensor


@partial(jax.jit, static_argnames=["qubit_indices"])
def calculate_fidelity_tensor_from_left_and_right_state(
    left_state_tensor, right_state_tensor, qubit_indices
):
    left_state = tn.Node(left_state_tensor, backend="jax")
    right_state = tn.Node(right_state_tensor, backend="jax")

    n_qubits = len(left_state.edges)
    ## connect trace edges
    for nq in range(n_qubits):
        if nq not in qubit_indices:
            tn.connect(left_state[nq], right_state[nq])

    ## F tensor
    full_fidelity_tensor = tn.contract_between(
        left_state,
        right_state,
        output_edge_order=[
            left_state[qubit_indices[0]],
            left_state[qubit_indices[1]],
            right_state[qubit_indices[0]],
            right_state[qubit_indices[1]],
        ],
        name="Fidelity Tensor",
    )
    return full_fidelity_tensor.tensor


@partial(jax.jit, static_argnames=["learning_rate"])
def calculate_new_unitary_tensor(
    full_fidelity_tensor_tensor, old_unitary_tensor, learning_rate
):
    unitary_node_m = tn.Node(old_unitary_tensor, backend="jax")
    full_fidelity_tensor = tn.Node(full_fidelity_tensor_tensor, backend="jax")

    u, s, v, _ = tn.split_node_full_svd(
        full_fidelity_tensor,
        left_edges=[full_fidelity_tensor[0], full_fidelity_tensor[1]],
        right_edges=[full_fidelity_tensor[2], full_fidelity_tensor[3]],
    )

    um_tensor = jax.numpy.tensordot(u.tensor, v.tensor, (-1, 0))

    if not np.isclose(learning_rate, 1):
        new_tensor = jax_interpolation_function(
            unitary_node_m.tensor, um_tensor, learning_rate
        )
        um_tensor = new_tensor.reshape(4 * [2])

    return um_tensor


@jit
def jax_unitarize(mat: np.ndarray):
    mat, r = jnp.linalg.qr(mat, mode="complete")
    mat = mat * jnp.sign(jnp.diag(r))
    return mat


def unitarize(mat: np.ndarray) -> np.ndarray:
    return np.asarray(jax_unitarize(mat), dtype=mat.dtype)


def get_unitary_linear_layer(
    n_qubits: int,
    theta: float = 0,
    name_extension: str = "",
    identity: bool = False,
) -> List[TNUnitaryNode]:
    all_unitaries = []
    for ii in reversed(range(n_qubits - 1)):
        if identity:
            random_u = np.eye(4) + np.random.normal(0, 1e-3, size=(4, 4))
        else:
            random_u = np.random.normal(size=(4, 4))
        unitary = unitarize(random_u)
        uni = tn.Node(
            unitary.reshape(4 * [2]),
            name=f"U({ii}, {ii+1}) " + name_extension,
        )
        entry = TNUnitaryNode((ii, ii + 1), uni)
        all_unitaries.append(entry)
    return all_unitaries


def reset_all_node_edges(all_nodes: List[tn.Node]):
    for node in all_nodes:
        node.fresh_edges()


@jax.jit
def contract_left_and_right_state(left_state_tensor, right_state_tensor):
    left_state = tn.Node(left_state_tensor, backend="jax")
    right_state = tn.Node(
        right_state_tensor.conj(), backend="jax"
    )  # .copy(conjugate=True)

    for left_edge, right_edge in zip(left_state.edges, right_state.edges):
        left_edge ^ right_edge
    return tn.contract_between(left_state, right_state).tensor


def interpolation_function(old_tensor, new_tensor, lr=1):
    return np.array(jax_interpolation_function(old_tensor, new_tensor, lr))


@jax.jit
def jax_interpolation_function(old_tensor, new_tensor, lr=1):
    old_tensor = old_tensor.reshape(4, 4)
    new_tensor = new_tensor.reshape(4, 4)

    modified_tensor = old_tensor.dot(
        jax_fractional_power((old_tensor.conj().T).dot(new_tensor), lr)
    )
    modified_tensor = jax_unitarize(modified_tensor)
    return modified_tensor.reshape(4 * [2])


@jax.jit
def jax_fractional_power(mat, p):
    d, v = jax.numpy.linalg.eig(mat)
    return v.dot(jax.numpy.diag(d) ** p).dot(jax.numpy.linalg.inv(v))
