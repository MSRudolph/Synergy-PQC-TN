from zqml.qeo.generators import MPSGenerator
from .utils import fill_distribution, Dataset
from .backend import StateNetwork

import numpy as np
from collections import Counter
from tqdm import tqdm
from typing import List, Optional


def train_mps(
    mps: MPSGenerator,
    n_iters: int,
    dataset: Dataset,
    verbose: bool = False,
) -> List[float]:
    mps_target_distribution = dataset.distribution_dict

    target_samples = np.array(list(mps_target_distribution.keys()))
    target_probs = np.array((list(mps_target_distribution.values())))

    for _ in tqdm(range(n_iters), desc="MPS training progress", disable=not verbose):
        mps.train(
            n_epochs=1, xtrain=target_samples, probs=target_probs, learning_rate=0.01
        )


def calculate_KL(model_distribution, target_distribution: dict):
    EPS = 1e-8
    KL = 0
    for bitstring, p_data in target_distribution.items():
        if bitstring in model_distribution.keys():
            KL += p_data * np.log(p_data) - p_data * np.log(
                max(EPS, model_distribution[bitstring])
            )
        else:
            KL += p_data * np.log(p_data) - p_data * np.log(EPS)
    return KL


def train_fidelity_network(
    net: StateNetwork,
    n_sweeps: int,
    lr: float = 0.6,
    break_threshold: float = 1 - 1e-4,
    eval_fidelity: bool = True,
    eval_dataset: Optional[Dataset] = None,
    verbose: bool = False,
):
    all_fidelities = []
    all_kls = []

    ## calculate training loss:
    if eval_dataset is not None:
        all_kls.append(
            net.reverse_network_from_target(fully_reverse=True).tensor.flatten()
        )

    for sweep in tqdm(range(n_sweeps), disable=not verbose):
        if eval_fidelity:
            all_fidelities.append(net.get_fidelity())
            if all_fidelities[-1] > break_threshold:
                return np.array(all_fidelities), np.array(all_kls)

        net.update_sweep(learning_rate=lr)

        # calculate training loss:
        if eval_dataset is not None:
            all_kls.append(
                net.reverse_network_from_target(fully_reverse=True).tensor.flatten()
            )
    return np.array(all_fidelities), all_kls
