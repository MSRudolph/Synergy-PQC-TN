from zqml.qeo.generators import MPSGenerator
from zquantum.core.circuits._gates import CustomGateDefinition
from zquantum.core.circuits import (
    CNOT,
    RX,
    RY,
    RZ,
    U3,
    XX,
    YY,
    ZZ,
    Circuit,
    CustomGateDefinition,
    Gate,
    GateOperation,
    H,
)
from zquantum.generative.numerical_optimization.analytic_mps_decomposition import (
    canonise_left_complex,
)
from typing import List, Optional, Union, Tuple
import tensornetwork as tn
import numpy as np
from copy import deepcopy
import warnings
from .backend import TNUnitaryNode, StateNetwork, unitarize
from .train import train_fidelity_network
from .utils import Topologies, get_graph_from_topology


matrix = np.ndarray
tensor = np.ndarray
unitary = np.ndarray


def decompose_mps(
    mps_target_node: tn.Node,
    n_initial_layers: int,
    n_sweeps=50,
    verbose=True,
    break_threshold=1 - 1e-3,
):
    model_unitaries: List[TNUnitaryNode] = []
    for rep in range(n_initial_layers):
        model_unitaries = decompose_one_layer_from_node(
            mps_target_node, model_unitaries
        )
        net = StateNetwork(target_node=mps_target_node, model_unitaries=model_unitaries)
        all_fidelities, _ = train_fidelity_network(
            net,
            n_sweeps,
            lr=0.6,
            verbose=verbose,
            break_threshold=break_threshold,
        )
        model_unitaries = deepcopy(net.model_unitaries)
    try:
        print("Final fidelity:", np.max(all_fidelities))
    except ValueError:
        pass

    return net


def decompose_one_layer_from_node(
    node: tn.Node,
    model_unitaries: Optional[List[TNUnitaryNode]] = None,
    shift_singular_values=True,
) -> List[TNUnitaryNode]:
    if model_unitaries is None:
        model_unitaries = []
    net = StateNetwork(target_node=node, model_unitaries=model_unitaries)
    disentangled_node = net.reverse_network_from_target()
    next_mps = get_truncated_mps_from_node(disentangled_node, 2, shift_singular_values)
    tensors = canonise_left_complex(
        next_mps.tensors,
        next_mps._max_bond_dim,
        next_mps._cutoff,
        next_mps.bond_dimensions,
    )
    next_unitary_list = get_unitary_gates_from_mps_tensors(
        tensors, next_mps.bond_dimensions
    )
    model_unitaries = np.append(
        convert_gate_list_into_model_unitaries(next_unitary_list),
        model_unitaries,
    )
    return model_unitaries


def decompose_one_layer_from_node(
    node: tn.Node,
    model_unitaries: Optional[List[TNUnitaryNode]] = None,
    shift_singular_values=True,
) -> List[TNUnitaryNode]:
    if model_unitaries is None:
        model_unitaries = []
    net = StateNetwork(target_node=node, model_unitaries=model_unitaries)
    disentangled_node = net.reverse_network_from_target()
    next_mps = get_truncated_mps_from_node(disentangled_node, 2, shift_singular_values)
    tensors = canonise_left_complex(
        next_mps.tensors,
        next_mps._max_bond_dim,
        next_mps._cutoff,
        next_mps.bond_dimensions,
    )
    next_unitary_list = get_unitary_gates_from_mps_tensors(
        tensors, next_mps.bond_dimensions
    )
    model_unitaries = np.append(
        convert_gate_list_into_model_unitaries(next_unitary_list),
        model_unitaries,
    )
    return model_unitaries


def get_unitary_gates_from_mps_tensors(
    mps_canonical_tensors, mps_bond_dimensions
) -> List[GateOperation]:
    num_tensors = len(mps_canonical_tensors)
    all_are_unitary = True
    gate_list = []
    for tensor_idx, tensor in enumerate(mps_canonical_tensors):
        reduced_tensor = process_tensor(
            tensor_idx, mps_canonical_tensors, mps_bond_dimensions
        )
        padded_tensor = pad_mps_tensors(reduced_tensor)
        gate_matrix = tensor_to_unitary(padded_tensor)

        n_interacting_qubits = round(np.log2(gate_matrix.shape[0]))
        qubit_indices: Union[Tuple[int], Tuple[int, int]]

        if tensor_idx == 0:
            name = "U3_"
            qubit_indices = (tensor_idx,)
        else:
            name = f"ENT{n_interacting_qubits}_{num_tensors-tensor_idx}"
            qubit_indices = tuple(
                (tensor_idx - ii for ii in range(n_interacting_qubits))
            )

        if not np.isclose(
            np.eye(len(gate_matrix)), np.dot(gate_matrix, gate_matrix.conj().T)
        ).all():
            all_are_unitary = False
            gate_matrix = unitarize(gate_matrix)

        gate = CustomGateDefinition(
            name,
            gate_matrix,
            (),
        )()(*qubit_indices)
        gate_list.append(gate)

    if not all_are_unitary:
        warnings.warn(
            "The resulting gates are not all unitary and they will be unitarized.\
                This does not preserve the effect of the gates. Please canonicalize the MPS tensors!"
        )

    return gate_list[::-1]


def pad_mps_tensors(tensor: tensor) -> tensor:
    """Pads a tensor such that bond dimension shapes are a power of two"""
    bond_dim_left, bond_dim_right = tensor.shape[0], tensor.shape[2]
    assert (
        tensor.shape[1] == 2
    ), f"Physical dimension needs to be 2, currently is {tensor.shape[1]}"
    max_bond_dim = bond_dim_left

    next_pow_of_two = _next_power_of_two(max_bond_dim)
    npad = (
        (0, next_pow_of_two - bond_dim_left),
        (0, 0),
        (0, max(next_pow_of_two - bond_dim_right, 0)),
    )
    padded_tensors = np.pad(
        tensor, pad_width=npad, mode="constant", constant_values=0.0
    )
    return padded_tensors


def _next_power_of_two(number: int) -> int:
    """Finds next power of two. Returns the number itself if it is power of two"""
    return 2 ** (number - 1).bit_length()


def convert_gate_list_into_model_unitaries(unitary_list):
    ### absorb the final U3 into the final SU4
    single_qubit_gate = np.dot(
        np.kron(unitary_list[-1].gate.matrix, np.eye(2)), unitary_list[-2].gate.matrix
    )
    new_unitary_list = deepcopy(unitary_list[:-1])
    new_unitary_list[-1] = CustomGateDefinition(
        gate_name=unitary_list[-2].gate.name,
        matrix=single_qubit_gate,
        params_ordering=(),
    )()(1, 0)
    ###
    model_unitaries = []
    for kk, gate in enumerate(new_unitary_list):
        model_unitaries.append(
            TNUnitaryNode(
                tuple(reversed(gate.qubit_indices)),
                tn.Node(
                    np.array(gate.gate.matrix).T.reshape(4 * [2]),
                    name=f"U{kk}{tuple(p for p in tuple(reversed(gate.qubit_indices)))}",
                ),
            )
        )
    return model_unitaries


def get_truncated_mps_from_node(
    node: tn.Node, new_max_bond_dim: int, shift_singular_values=True
) -> MPSGenerator:
    n_qubits = len(node.edges)

    ## split up the large target node
    node = node.copy()
    node.tensor = node.tensor

    final_nodes = []
    dropped_singular_values = []
    for ii in range(n_qubits - 1):
        if ii == 0:
            edge_idx = 1
        else:
            edge_idx = 2
        if not shift_singular_values:
            u, node, err = tn.split_node(
                node,
                left_edges=[*node.edges[:edge_idx]],
                right_edges=[*node.edges[edge_idx:]],
                max_singular_values=new_max_bond_dim,
            )
        else:
            u, s, node, err = tn.split_node_full_svd(
                node,
                left_edges=[*node.edges[:edge_idx]],
                right_edges=[*node.edges[edge_idx:]],
                max_singular_values=new_max_bond_dim,
            )
            node = tn.contract_between(s, node)
        final_nodes.append(u)
        dropped_singular_values.extend(err)
    final_nodes.append(node)
    # print(
    #     "Average dropped singular values per node:",
    #     np.mean(np.abs(dropped_singular_values), dtype=float),
    # )

    truncated_tensors = convert_target_nodes_to_MPS_tensors(
        final_nodes, new_max_bond_dim
    )
    ##
    new_mps = _create_mps_from_tensors(truncated_tensors, new_max_bond_dim)

    return new_mps


def _create_mps_from_tensors(tensors, max_bond_dim) -> MPSGenerator:
    mps = MPSGenerator(len(tensors), max_bond_dim)
    mps.bond_dimensions = np.minimum(
        list(reversed([2**n for n in range(len(tensors))])), max_bond_dim
    )
    mps.tensors = canonise_left_complex(
        tensors,
        max_bond_dim,
        mps._cutoff,
        mps.bond_dimensions,
    )
    return mps


def convert_target_nodes_to_MPS_tensors(final_nodes: List[tn.Node], max_bond_dim):
    compact_tensors = [node.tensor for node in final_nodes]
    padded_tensors = deepcopy(compact_tensors)

    padded_tensors[0] = pad_tensor(padded_tensors[0][None, :, :], max_bond_dim)
    padded_tensors[-1] = pad_tensor(padded_tensors[-1][:, :, None], max_bond_dim)
    for ii in range(1, len(padded_tensors) - 1):
        padded_tensors[ii] = pad_tensor(padded_tensors[ii], max_bond_dim)
    return np.array(padded_tensors)


def convert_MPS_tensors_to_target_node(mps: MPSGenerator):
    """This function accepts MPS tensors in the format that z-quantum-qeo currently has."""

    canonical_tensors = np.array(mps.tensors)
    bond_dims = np.array(mps.bond_dimensions)
    bond_dims[:-1] = np.where(bond_dims[:-1] < 2, 2, bond_dims[:-1])
    ##
    processed_tensors = [
        process_tensor(tensor_idx, canonical_tensors, bond_dims).squeeze()
        for tensor_idx, tensor in enumerate(canonical_tensors)
    ]
    ##
    final_nodes: List[tn.Node] = []
    with tn.NodeCollection(final_nodes):
        final_nodes = [tn.Node(t) for t in processed_tensors]

    for ii in range(len(final_nodes) - 1):
        final_nodes[ii][-1] ^ final_nodes[ii + 1][0]

    final_edges = [0] + [1] * (len(final_nodes) - 2) + [-1]
    ##
    mps_node = tn.contractors.auto(
        final_nodes,
        output_edge_order=[node[idx] for node, idx in zip(final_nodes, final_edges)],
    )
    mps_node.name = "MPS state"
    return mps_node


def process_tensor(idx: int, tensors: tensor, bond_dims: List[int]) -> tensor:
    tensors = np.array(tensors)
    bond_dims = np.array(bond_dims)
    tensor = tensors[idx][: bond_dims[idx - 1], :, : bond_dims[idx]]
    return tensor


def pad_tensor(compact_tensor, max_bond_dim):
    npad = (
        (0, max_bond_dim - compact_tensor.shape[0]),
        (0, 0),
        (0, max_bond_dim - compact_tensor.shape[2]),
    )
    padded_tensors = np.pad(
        compact_tensor, pad_width=npad, mode="constant", constant_values=0.0
    )
    return padded_tensors


def get_unitary_list_from_net_unitaries(
    model_unitaries: List[TNUnitaryNode], site_order=None
):
    approximated_unitary_list = []
    for k, entry in enumerate(model_unitaries):
        if site_order is not None:
            participating_qubits = tuple(
                site_order[ii]
                for ii in reversed(tuple(p for p in entry.participating_qubits))
            )
        else:
            participating_qubits = tuple(
                ii for ii in reversed(tuple(p for p in entry.participating_qubits))
            )
        node = entry.node
        unitary = node.tensor.reshape(4, 4).T
        approximated_unitary_list.append(
            CustomGateDefinition(
                f"U{k}{tuple(p for p in participating_qubits)}", unitary, ()
            )()(*participating_qubits)
        )
    return approximated_unitary_list


identity = CustomGateDefinition("id", np.eye(4, dtype=np.complex128), ())()


def extend_unitary_list_with_ansatz(
    Nx: int,
    Ny: int,
    unitary_list: List[GateOperation],
    entangling_topologies: List[Topologies],
) -> List[GateOperation]:
    n_qubits = Nx * Ny
    n_total_layers = len(entangling_topologies)
    # NOTE: This might only work in conjunction with the MPS decomposition, not arbitrary unitary_lists
    n_net_layers = round(len(unitary_list) / (n_qubits - 1))

    unitary_list = deepcopy(unitary_list)
    # filling up if too few layers were passed
    if n_net_layers > n_total_layers:
        for _ in range(n_net_layers - n_total_layers):
            entangling_topologies.append(Topologies.line)
        n_total_layers = n_net_layers
    #
    ansatz_unitary_list = []
    gate_counter = 0
    for layer_idx in range(n_total_layers):
        entangling_graph = get_graph_from_topology(
            entangling_topologies[layer_idx], Nx, Ny
        )

        if layer_idx < n_net_layers:
            this_layer_pretrained_gates_dict = {
                gate.qubit_indices: gate
                for gate in unitary_list[gate_counter : gate_counter + (n_qubits - 1)]
            }
            gate_counter += n_qubits - 1
        else:
            this_layer_pretrained_gates_dict = {}

        for pair in this_layer_pretrained_gates_dict:
            ansatz_unitary_list.append(this_layer_pretrained_gates_dict[pair])

        if (
            entangling_topologies[layer_idx] == Topologies.line
            and len(this_layer_pretrained_gates_dict) > 0
        ):
            # skip if this is line topology, because the line follows the MPS site order
            continue

        for pair in entangling_graph.edges:
            if (
                pair not in this_layer_pretrained_gates_dict
                and tuple(reversed(pair)) not in this_layer_pretrained_gates_dict
            ):
                ansatz_unitary_list.append(identity(*pair))

    return ansatz_unitary_list


def convert_gate_list_to_circuit(gate_list: List[GateOperation]) -> Circuit:
    circuit = Circuit()
    for gate in gate_list:
        circuit += gate
    return circuit


def tensor_to_unitary(A: tensor) -> unitary:
    """given a left isometric tensor A, put into a unitary.
    NOTE: A should be left canonical: No checks!
    """
    D, d, l = A.shape
    iso = A.reshape(D * d, l)
    U = unitary_extension(iso)
    return U


def unitary_extension(Q: matrix) -> unitary:
    """extend an isometry to a unitary (doesn't check its an isometry)"""
    from scipy.linalg import null_space

    s = Q.shape
    if s[0] > s[1]:
        N2 = null_space(Q.conj().T)
        new_cols = N2.shape[1]
        Q_ = np.concatenate([Q[:, : s[0] - new_cols], N2], 1)
    elif s[0] < s[1]:
        N1 = null_space(Q)
        new_rows = N1.shape[0]
        Q_ = np.concatenate([Q.conj().T[: s[1] - new_rows], N1], 1).conj().T
    else:
        Q_ = Q
    return Q_
