import numpy as np
import matplotlib.pyplot as plt
from collections import Counter
import networkx as nx
from zquantum.qcbm.target import (
    get_bars_and_stripes_target_distribution as _get_bars_and_stripes_target_distribution,
)
from zquantum.core.bitstring_distribution import BitstringDistribution
from zquantum.generative.dataset import Dataset
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Union, Dict, List, Tuple, Optional, Iterable
from enum import Enum, auto


class Topologies(Enum):
    line = auto()
    grid = auto()
    torus = auto()
    all = auto()


def fill_distribution(distribution_dict):
    example_key = list(distribution_dict.keys())[0]
    n_qubits = len(example_key)  # length of bitstring
    sum_probs = sum(distribution_dict.values())
    #
    all_bins = [bin(i)[2:].zfill(n_qubits) for i in range(2**n_qubits)]
    if isinstance(example_key, tuple):
        all_bins = [tuple(int(i) for i in string) for string in all_bins]
    base_dict = {num: 0.0 for num in all_bins}
    # build complete distribution dict where distr.items() are ordered in binary, just like in the histogram
    distr = Counter()
    for k in base_dict.keys():
        if k in distribution_dict.keys():
            distr[k] = distribution_dict[k] / sum_probs
        else:
            distr[k] = 0.0
    return distr


def plot_full_distribution(distribution_dict: dict, **plot_kwargs):
    full_distribution_dict = fill_distribution(distribution_dict)
    plt.plot(full_distribution_dict.values(), **plot_kwargs)


def get_snake_order(Nx: int, Ny: int):
    snake_order: List[int] = []
    for ny_counter in range(Ny):
        if ny_counter % 2 == 0:
            snake_order.extend(range(ny_counter * Nx, ny_counter * Nx + Nx))
        else:
            snake_order.extend(reversed(range(ny_counter * Nx, ny_counter * Nx + Nx)))

    return snake_order


def get_cardinality_dataset(n_qubits):
    universe_size = n_qubits
    cardinality = universe_size // 2

    def generate_binary_strings(bit_count):
        binary_strings = []

        def genbin(n, bs=""):
            if len(bs) == n:
                binary_strings.append(bs)
            else:
                genbin(n, bs + "0")
                genbin(n, bs + "1")

        genbin(bit_count)
        return binary_strings

    binary_strings = generate_binary_strings(n_qubits)
    card_strings = np.array([b for b in binary_strings if b.count("1") == cardinality])
    num_strings = len(card_strings)
    card_distribution = dict(zip(card_strings, [1 / num_strings] * num_strings))
    return Dataset(card_distribution)


def get_graph_from_topology(topology: Topologies, Nx: int, Ny: int) -> nx.Graph:
    if topology == Topologies.line:
        entangling_graph = get_line_topology(Nx * Ny)
    elif topology == Topologies.grid:
        entangling_graph = get_2d_topology(Nx, Ny)
    elif topology == Topologies.torus:
        entangling_graph = get_torus_topology(Nx, Ny)
    elif topology == Topologies.all:
        entangling_graph = get_all_topology(Nx * Ny)
    else:
        raise Exception(
            f"Entangling graph {topology} is not one of the available options in zquantum.generative.pretraining.workflow_functions.graphs, using the Enum Topologies class."
        )
    return entangling_graph


def get_2d_topology(Nx: int, Ny: int):
    edge_list = []

    for ny_counter in range(Ny):
        # connects inside rows
        edge_list.extend(
            [(ii, ii + 1) for ii in range(ny_counter * Nx, (ny_counter + 1) * Nx - 1)]
        )
        # connects between rows
        if ny_counter + 1 < Ny:
            edge_list.extend(
                [(ii, ii + Nx) for ii in range(ny_counter * Nx, (ny_counter + 1) * Nx)]
            )

    entangling_graph = nx.from_edgelist(edge_list)
    return entangling_graph


def get_torus_topology(Nx: int, Ny: int):
    edge_list = []

    for ny_counter in range(Ny):
        # connects inside rows
        edge_list.extend(
            [
                (ii, (ii + 1) % Nx + ny_counter * Nx)
                for ii in range(ny_counter * Nx, (ny_counter + 1) * Nx)
            ]
        )
        # connects between rows
        edge_list.extend(
            [
                (ii, (ii + Nx) % (Nx * Ny))
                for ii in range(ny_counter * Nx, (ny_counter + 1) * Nx)
            ]
        )
    edge_list = [edge for edge in edge_list if edge[0] != edge[1]]
    entangling_graph = nx.from_edgelist(edge_list)
    return entangling_graph


def get_line_topology(n_qubits):
    edge_list = [(ii, ii + 1) for ii in range(n_qubits - 1)]

    entangling_graph = nx.from_edgelist(edge_list)
    return entangling_graph


def get_all_topology(n_qubits):
    edge_list = [(ii, jj) for ii in range(n_qubits) for jj in range(ii)]

    entangling_graph = nx.from_edgelist(edge_list)
    return entangling_graph
