import numpy as np

n_qubits = 10
max_bond_dim = 6
num_decomposition_layers = 3
n_sweeps = 100
circuit_depth = 3

################### Dataset ####################################
from src.utils import get_cardinality_dataset

dataset = get_cardinality_dataset(n_qubits)

from src.utils import fill_distribution

target_distribution = dataset.distribution_dict
full_target_distribution = fill_distribution(target_distribution)
target_probabilities = np.array(list(full_target_distribution.values()))


################### MPS Training ####################################
from zqml.qeo.generators import MPSGenerator

mps = MPSGenerator(n_qubits, max_bond_dim=max_bond_dim)
from src.train import train_mps

kls_mps = train_mps(mps, 100, dataset, verbose=False)
from src.decomposition import convert_MPS_tensors_to_target_node

mps_target = convert_MPS_tensors_to_target_node(mps)

################### MPS Decomposition ####################################

from src.decomposition import decompose_mps, get_unitary_list_from_net_unitaries

net = decompose_mps(
    mps_target,
    num_decomposition_layers,
    n_sweeps=n_sweeps,
    verbose=True,
    break_threshold=1 - 1e-5,
)
approximated_unitary_list = get_unitary_list_from_net_unitaries(net.model_unitaries)

from zquantum.core.circuits import Circuit, CustomGateDefinition, GateOperation

### Add extra linear layers
for k in range(circuit_depth - num_decomposition_layers):
    for ii in range(n_qubits - 1, 0, -1):
        participating_qubits = (ii, ii - 1)
        unitary = np.eye(4)
        approximated_unitary_list.append(
            CustomGateDefinition(
                f"U{k+1}{tuple(p for p in participating_qubits)}", unitary, ()
            )()(*participating_qubits)
        )

################### Extend circuit with gates ####################################
from src.utils import Topologies

topology = Topologies.all
entangling_topologies = [Topologies.line] * (circuit_depth - 1) + [topology]
from src.decomposition import extend_unitary_list_with_ansatz

Nx = n_qubits
Ny = 1
ansatz_unitary_list = extend_unitary_list_with_ansatz(
    Nx,
    Ny,
    approximated_unitary_list,
    entangling_topologies,
)
